<?php
// ------------------------------------------------------------------
// - NAME:        widgetclass.php
// - AUTHOR:      Reto Stauffer
// - DATE:        2014-07-09
// ------------------------------------------------------------------
// - DESCRIPTION: Defines and offers the wetterturnier widgets.
//                Or at least one?  
// ------------------------------------------------------------------

class WP_wetterturnier_widget_judgement extends WP_Widget
{

    // --------------------------------------------------------------
    // Constructor method: construct the plugin
    // --------------------------------------------------------------
    function __construct() {

        // Register jquery needed for this plugin
        wp_register_style(  'wtwidget_judgement_css', plugins_url('../../css/widget.judgement.css',__FILE__) );
        wp_enqueue_style(  'wtwidget_judgement_css' );

        // Widget  options
        $widget_ops = array('classname'=>'wtwidget_judgement',
                            'description'=>__('Wetterturnier points calculator') );
        // those are completely default at the moment TODO remove or use
        $control_ops = array('width'=>300, 'height'=>350, 'id_base'=>'wp_wetterturnier_judgement' );
        $this->WP_Widget('wtwidget_judgement', __('Wetterturnier Calc'),"widget",
                         $widget_ops, $control_ops );
    }


    // --------------------------------------------------------------
    // widget admin form creation
    // --------------------------------------------------------------
    function form($instance) {  
        // Check values
        if( $instance) {
             $title = esc_attr($instance['title']);
             $text = esc_attr($instance['text']);
             $textarea = esc_textarea($instance['textarea']);
        } else {
             $title = '';
             $text = '';
             $textarea = '';
        }
        ?>
        
        <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Widget Title', 'wp_widget_plugin'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
        </p>
        
        <p>
        <label for="<?php echo $this->get_field_id('text'); ?>"><?php _e('Text:', 'wp_widget_plugin'); ?></label>
        <input class="widefat" id="<?php echo $this->get_field_id('text'); ?>" name="<?php echo $this->get_field_name('text'); ?>" type="text" value="<?php echo $text; ?>" />
        </p>
        
        <p>
        <label for="<?php echo $this->get_field_id('textarea'); ?>"><?php _e('Textarea:', 'wp_widget_plugin'); ?></label>
        <textarea class="widefat" id="<?php echo $this->get_field_id('textarea'); ?>" name="<?php echo $this->get_field_name('textarea'); ?>"><?php echo $textarea; ?></textarea>
        </p>
        <?php
    }

    // --------------------------------------------------------------
    // widget update
    // --------------------------------------------------------------
    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        // Fields
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['text'] = strip_tags($new_instance['text']);
        $instance['textarea'] = strip_tags($new_instance['textarea']);
        return $instance;
    }


    // --------------------------------------------------------------
    // widget display
    // --------------------------------------------------------------
    function widget( $args, $instance ) { //, $instance) {


        extract( $args, EXTR_SKIP );

        // these are the widget options
        $title = $instance['title']; #apply_filters('widget_title', $instance['title']);
        $text = $instance['text'];
        $textarea = $instance['textarea'];

        echo $before_widget;
        // Display the widget
        echo '<div class="widget-text wp_widget_plugin_box">';

        // Check if title is set
        if ( $title ) { echo $before_title . $title . $after_title; }
        // Check if text is set
        if( $text ) { echo '<p class="wp_widget_plugin_text">'.$text.'</p>'; }
        // Check if textarea is set
        if( $textarea ) { echo '<p class="wp_widget_plugin_textarea">'.$textarea.'</p>'; }

        // Loading parameter infos
        global $WTuser;
        $params = $WTuser->get_param_data();


        ?>
        <form id='wtwidget-judgement-form'>
        <?php _e('Choose your parameter'); ?><br>
        <select id='wtwidget-param' name='param'>
            <?php foreach( $params as $param ) {
                if ( $param->paramName == 'ff' ) { $s = 'selected'; } else { $s = ''; }
                echo "<option value='".$param->paramName."' ".$s.">".$param->thename."</option>";
            } ?>
        </select>
        <fd><?php _e('Forecasted value'); ?></fd>
        <input id='wtwidget-value' type='text' name='value' value="10" /><br>
        <fd><?php _e('Observed value(s)'); ?></fd>
        <input id='wtwidget-obs1' type='text' name='obs1' value="9" /><br>
        <fd>&nbsp;</fd>
        <input id='wtwidget-obs2' type='text' name='obs1' value="7" /><br>
        <fd><?php _e('Result'); ?></fd>
        <input id='wtwidget-result' type='text' name='obs1' value="" disabled /><br>
        <fd>&nbsp;</fd>
        <button id='wtwidget-calc' type='button'><?php _e("calculate"); ?></button>

        </form>
        <?php
        
        echo '</div>';
        echo $after_widget;
    }

}
// Add widget to wordpress
add_action('widgets_init', function() { register_widget("WP_wetterturnier_widget_judgement"); });


// -------------------------------------------------------------------------------------------------
// -------------------------------------------------------------------------------------------------
//                                 BELOW IS THE JQUERY STUFF PLUS AJAX CALL
// -------------------------------------------------------------------------------------------------
// -------------------------------------------------------------------------------------------------

// Addsd the jquery code to the head.
// This makes it available for the plugin.
function wtwidget_judgeing_js() {
    ?>
    <script type='text/javascript'>
    jQuery(document).on('ready',function() {
        (function($) {
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
            $("#wtwidget-calc").on("click",function() {
                $('#wtwidget-result').attr('value','');
                var obs1  = $("#wtwidget-obs1").attr('value');
                var obs2  = $("#wtwidget-obs2").attr('value');
                var value = $("#wtwidget-value").attr('value');
                var param = $("#wtwidget-param").val();
                
                // Ajaxing the calculation miniscript
                $.ajax({
                    url: ajaxurl, 
                    dataType: 'html',
                    type: 'post',
                    data: {'action':'wtwidget_judgeing_ajax','obs1':obs1,'obs2':obs2,'value':value,'param':param},
                    success: function(results) {
                        $('#wtwidget-result').attr('value',results);
                    }
                });
            });
        })(jQuery);
    });
    </script>
    <?php
}

// This is the call made by ajax (jquery) when the user
// is pressing the button or whatever (see function above).
function wtwidget_judgeing_ajax() {

    // Getting the arguments
    $JC = new WP_wetterturnier_judgeingclass();
    
    // We need at least one "value" (bet) and one observation
    if ( empty($_POST['param']) ) {
        return false;
    } elseif ( empty($_POST['value']) | ( empty($_POST['obs1']) & empty($_POST['obs2']) ) ) {
        return false;
    }
    if ( ! empty($_POST['obs1']) & empty($_POST['obs2']) )
    {
        $obs = array($_POST['obs1']*10.);
    }
    elseif ( empty($_POST['obs1']) & ! empty($_POST['obs2']) )
    {
        $obs = array($_POST['obs2']*10.);
    }
    else
    {
        $obs = array($_POST['obs1']*10.,$_POST['obs2']*10.);
    }
    // Scale the value, too
    $value = $_POST['value'] * 10.;

    // Check if we can call the method
    if ( method_exists($JC,$_POST['param']) ) {
        print call_user_func(array($JC,$_POST['param']),$JC,0,$value,$obs);
    }
    
    die();

}

// Add action to wordpress to make the code callable
add_action('wp_head','wtwidget_judgeing_js');
add_action('wp_ajax_wtwidget_judgeing_ajax','wtwidget_judgeing_ajax');


