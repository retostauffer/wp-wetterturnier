<?php

// Addsd the jquery code to the head.
// This makes it available for the plugin.
function wtwidget_judgeing_js() {
    ?>
    <script type='text/javascript'>
    jQuery(document).on('ready',function() {
        (function($) {
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
            $("#wtwidget-calc").on("click",function() {
                $('#wtwidget-result').attr('value','');
                var obs1  = $("#wtwidget-obs1").attr('value');
                var obs2  = $("#wtwidget-obs2").attr('value');
                var value = $("#wtwidget-value").attr('value');
                var param = $("#wtwidget-param").val();
                
                // Ajaxing the calculation miniscript
                $.ajax({
                    url: ajaxurl, 
                    dataType: 'html',
                    type: 'post',
                    data: {'action':'wtwidget_judgeing_ajax','obs1':obs1,'obs2':obs2,'value':value,'param':param},
                    success: function(results) {
                        $('#wtwidget-result').attr('value',results);
                    }
                });
            });
        })(jQuery);
    });
    </script>
    <?php
}

// This is the call made by ajax (jquery) when the user
// is pressing the button or whatever (see function above).
function wtwidget_judgeing_ajax() {

    // Getting the arguments
    $JC = new WP_wetterturnier_judgeingclass();
    
    // We need at least one "value" (bet) and one observation
    if ( empty($_POST['param']) ) {
        return false;
    } elseif ( empty($_POST['value']) | ( empty($_POST['obs1']) & empty($_POST['obs2']) ) ) {
        return false;
    }
    if ( ! empty($_POST['obs1']) & empty($_POST['obs2']) )
    {
        $obs = array($_POST['obs1']*10.);
    }
    elseif ( empty($_POST['obs1']) & ! empty($_POST['obs2']) )
    {
        $obs = array($_POST['obs2']*10.);
    }
    else
    {
        $obs = array($_POST['obs1']*10.,$_POST['obs2']*10.);
    }
    // Scale the value, too
    $value = $_POST['value'] * 10.;

    // Check if we can call the method
    if ( method_exists($JC,$_POST['param']) ) {
        print call_user_func(array($JC,$_POST['param']),$JC,0,$value,$obs);
    }
    
    die();

}

// Add action to wordpress to make the code callable
add_action('wp_head','wtwidget_judgeing_js');
add_action('wp_ajax_wtwidget_judgeing_ajax','wtwidget_judgeing_ajax');


